﻿namespace Projeto1
{
    partial class frmEnvioMensagem
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEnvioMensagem));
            this.lblInteiro = new System.Windows.Forms.Label();
            this.txtInteiro = new System.Windows.Forms.TextBox();
            this.lblDecimal = new System.Windows.Forms.Label();
            this.txtDecimal = new System.Windows.Forms.TextBox();
            this.lblTexo = new System.Windows.Forms.Label();
            this.txtTexti = new System.Windows.Forms.TextBox();
            this.lblBooleano = new System.Windows.Forms.Label();
            this.txtBooleano = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInteiro
            // 
            this.lblInteiro.AutoSize = true;
            this.lblInteiro.BackColor = System.Drawing.Color.Transparent;
            this.lblInteiro.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInteiro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblInteiro.Location = new System.Drawing.Point(11, 37);
            this.lblInteiro.Name = "lblInteiro";
            this.lblInteiro.Size = new System.Drawing.Size(83, 28);
            this.lblInteiro.TabIndex = 0;
            this.lblInteiro.Text = "Inteiro";
            this.lblInteiro.Click += new System.EventHandler(this.lblInteiro_Click_1);
            // 
            // txtInteiro
            // 
            this.txtInteiro.Location = new System.Drawing.Point(12, 68);
            this.txtInteiro.Name = "txtInteiro";
            this.txtInteiro.Size = new System.Drawing.Size(233, 20);
            this.txtInteiro.TabIndex = 1;
            // 
            // lblDecimal
            // 
            this.lblDecimal.AutoSize = true;
            this.lblDecimal.BackColor = System.Drawing.Color.Transparent;
            this.lblDecimal.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDecimal.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDecimal.Location = new System.Drawing.Point(12, 100);
            this.lblDecimal.Name = "lblDecimal";
            this.lblDecimal.Size = new System.Drawing.Size(97, 28);
            this.lblDecimal.TabIndex = 2;
            this.lblDecimal.Text = "Decimal";
            // 
            // txtDecimal
            // 
            this.txtDecimal.Location = new System.Drawing.Point(12, 131);
            this.txtDecimal.Name = "txtDecimal";
            this.txtDecimal.Size = new System.Drawing.Size(233, 20);
            this.txtDecimal.TabIndex = 3;
            // 
            // lblTexo
            // 
            this.lblTexo.AutoSize = true;
            this.lblTexo.BackColor = System.Drawing.Color.Transparent;
            this.lblTexo.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTexo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTexo.Location = new System.Drawing.Point(12, 164);
            this.lblTexo.Name = "lblTexo";
            this.lblTexo.Size = new System.Drawing.Size(72, 28);
            this.lblTexo.TabIndex = 4;
            this.lblTexo.Text = "Texto";
            // 
            // txtTexti
            // 
            this.txtTexti.Location = new System.Drawing.Point(16, 195);
            this.txtTexti.Name = "txtTexti";
            this.txtTexti.Size = new System.Drawing.Size(229, 20);
            this.txtTexti.TabIndex = 5;
            // 
            // lblBooleano
            // 
            this.lblBooleano.AutoSize = true;
            this.lblBooleano.BackColor = System.Drawing.Color.Transparent;
            this.lblBooleano.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBooleano.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblBooleano.Location = new System.Drawing.Point(11, 237);
            this.lblBooleano.Name = "lblBooleano";
            this.lblBooleano.Size = new System.Drawing.Size(112, 28);
            this.lblBooleano.TabIndex = 6;
            this.lblBooleano.Text = "Booleano";
            // 
            // txtBooleano
            // 
            this.txtBooleano.Location = new System.Drawing.Point(17, 268);
            this.txtBooleano.Name = "txtBooleano";
            this.txtBooleano.Size = new System.Drawing.Size(228, 20);
            this.txtBooleano.TabIndex = 7;
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.Color.Transparent;
            this.btnLimpar.Font = new System.Drawing.Font("bizagi-font", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.ForeColor = System.Drawing.Color.Black;
            this.btnLimpar.Location = new System.Drawing.Point(134, 311);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(111, 49);
            this.btnLimpar.TabIndex = 9;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = false;
            // 
            // btnMostrar
            // 
            this.btnMostrar.BackColor = System.Drawing.Color.Transparent;
            this.btnMostrar.Font = new System.Drawing.Font("bizagi-font", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrar.ForeColor = System.Drawing.Color.Black;
            this.btnMostrar.Location = new System.Drawing.Point(17, 311);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(105, 48);
            this.btnMostrar.TabIndex = 10;
            this.btnMostrar.Text = "MOSTRAR";
            this.btnMostrar.UseVisualStyleBackColor = false;
            // 
            // frmEnvioMensagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Projeto1.Properties.Resources.fotis_fotopoulos_LJ9KY8pIH3E_unsplash;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(274, 450);
            this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtBooleano);
            this.Controls.Add(this.lblBooleano);
            this.Controls.Add(this.txtTexti);
            this.Controls.Add(this.lblTexo);
            this.Controls.Add(this.txtDecimal);
            this.Controls.Add(this.lblDecimal);
            this.Controls.Add(this.txtInteiro);
            this.Controls.Add(this.lblInteiro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmEnvioMensagem";
            this.Text = "Envio de Mensagens";
            this.Load += new System.EventHandler(this.frmEnvioMensagem_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInteiro;
        private System.Windows.Forms.TextBox txtInteiro;
        private System.Windows.Forms.Label lblDecimal;
        private System.Windows.Forms.TextBox txtDecimal;
        private System.Windows.Forms.Label lblTexo;
        private System.Windows.Forms.TextBox txtTexti;
        private System.Windows.Forms.Label lblBooleano;
        private System.Windows.Forms.TextBox txtBooleano;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnMostrar;
    }
}

