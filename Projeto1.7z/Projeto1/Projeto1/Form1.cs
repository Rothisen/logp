﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto1
{
    public partial class frmEnvioMensagem : Form
    {
        public frmEnvioMensagem()
        {
            InitializeComponent();
        }

        private void frmEnvioMensagem_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu o formulario");
        }
        private void lblInteiro_click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label Inteiro");
        }
        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no textbox do inteiro");
        }
        private void lblDecimal_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label decimal");
        }
        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no textbox do decimal");
        }
        private void lblTexto_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label texto");
        }
        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no textbox do texto");
        }
        private void lblBooleano_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei na label Booleano");
        }
        private void txtBooleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no textbox do Booleano");
        }
        private void btnMostrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botao Mostrar");
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei no botao Limpar");
        }

    }    
}
